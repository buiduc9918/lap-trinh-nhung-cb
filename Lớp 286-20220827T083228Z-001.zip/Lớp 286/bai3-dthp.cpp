#include <bits/stdc++.h>

using namespace std;

vector <vector<int> > dsk;
int mau[1050]; 
bool haiPhia (int v, int j) {
	mau[j] = 1;
	
	queue <int> q;
	q.push(j);
	
	while (q.empty() == false) {
		int top = q.front();
		q.pop();
		
		for (int i = 0; i < dsk[top].size(); i++)
			if (dsk[top][i] == top)
				return false;
			else if (mau[dsk[top][i]] == -1) { 
				mau[dsk[top][i]] = 1 - mau[top]; 
				q.push(dsk[top][i]);
			}
			else if (mau[dsk[top][i]] == mau[top])
				return false;
	}
	
	return true;
}

void prob03 (int v) { // nham tong quat cho truong hop do thi khong lien thong
	memset(mau, -1, sizeof(mau));
	
	for (int i = 1; i <= v; i++)
		if (mau[i] == -1 && haiPhia(v, i) == false) {
			cout << "NO";
			return;
		}
	
	cout << "YES";
}

int main (){
	int T, v, e;
	
	cin >> T;
	for (int t = 1; t <= T; t++){
		cin >> v >> e;
		
		dsk.clear();
		dsk.resize(v+1);
		
		for (int i = 0; i < e; i++) {
			int x, y;
			cin >> x >> y;
			
			dsk[x].push_back(y);
			dsk[y].push_back(x);
		}
		
		prob03(v);
		cout << endl;
	}
	
	return 0;
}
