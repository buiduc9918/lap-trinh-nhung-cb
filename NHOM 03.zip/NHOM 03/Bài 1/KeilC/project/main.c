#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "lcd16x2.h"
#include "delay.h"
#include "PWM.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SYS_CLK 					(8000000)
#define PSC 							(7)
#define MIN_PERIOD 				(99)
#define MAX_PERIOD 				(999)

void Clock_Config(void)
{
	/* RCC system reset */
	RCC_DeInit();
	/* HCLK = SYSCLK */
	RCC_HCLKConfig(RCC_SYSCLK_Div1); 
	/* PCLK2 = HCLK */
	RCC_PCLK2Config(RCC_HCLK_Div2);
	/* PCLK1 = HCLK/2 */
	RCC_PCLK1Config(RCC_HCLK_Div2);
	/*enable HSI source clock*/
	RCC_HSICmd(ENABLE); 
	/* Wait till PLL is ready */
	while (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET){}
	/* Select PLL as system clock source */
	RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
	/* Wait till PLL is used as system clock source */
	while(RCC_GetSYSCLKSource() != 0x00) {}    
}

void LCD_Number(uint16_t* value)
{
	char str[6];
	str[5] = '\0';
	str[0] = (char)((*value/10000) + '0');
	str[1] = (char)((*value/1000)%10 + '0');
	str[2] = (char)((*value/100)%10 + '0');
	str[3] = (char)((*value/10)%10 + '0');	
	str[4] = (char)((*value%10) + '0');	
	LCD_Gotoxy(0,1);
	LCD_Puts(str);	
}

void ADC_config_ch0()
{
    //cau hinh cho chan GPIO va bo ADC hoat dong
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 , ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;
    
    /*cau hinh chan Input cua bo ADC1 la chan PA0*/
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
 
    //cau hinh ADC
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);
    
    /* Cau hinh chanel, rank, thoi gian lay mau */
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5);
    /* Cho phep bo ADC1 hoat dong */
    ADC_Cmd(ADC1, ENABLE);
 
    /* Bat dau chuyen doi ADC */ 
    ADC_SoftwareStartConvCmd(ADC1, ENABLE); 
}

int16_t Map(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

int main(void)
{
    // Delay initialization
		Clock_Config();
		SystemCoreClockUpdate(); // update SystemCoreClock varibale
    Delay_Init();
    // LCD initialization
    LCD_Init();
		ADC_config_ch0(); 
		TIM_Base_Config(TIM3, PSC, MAX_PERIOD);
		TIM_PWM_Channel_Config(TIM3, CHANNEL_2);
		char string[20];
    while(1)
		{
			LCD_Gotoxy(0,0);
			LCD_Puts("Tan so(hz):");
			uint16_t adc_value0 = ADC_GetConversionValue(ADC1);
			uint16_t period = Map(adc_value0, 0, 4095, MIN_PERIOD, MAX_PERIOD);
			TIM_SetAutoreload(TIM3, period);
			uint16_t disValue = SYS_CLK / ((PSC + 1) * (period + 1));
			LCD_Number(&disValue);
			TIM2_Ms(10);
    }       
 
}
